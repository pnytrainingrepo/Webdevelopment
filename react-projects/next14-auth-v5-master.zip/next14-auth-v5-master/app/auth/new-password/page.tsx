import { NewPasswordForm } from '@/components/auth/new-password-form'

export default function Page() {
  return <NewPasswordForm />
}
