import { ErrorCard } from '@/components/auth/error-card'

export default function Page() {
  return <ErrorCard />
}
