import { LoginForm } from '@/components/auth/login-form'

export default function Page() {
  return <LoginForm />
}
